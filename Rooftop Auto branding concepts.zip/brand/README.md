# Rooftop Auto — brand assets (direction 3a, "Shelter" coupe)

A Litespeed company. Mark = roof chevron over a coupe silhouette.

## Files

**brand/svg/** — vector, use these for anything printed, embroidered, or scaled
- `mark-primary.svg` — blue roof + light car (for dark backgrounds), transparent
- `mark-primary-onlight.svg` — blue roof + near-black car (for light backgrounds)
- `mark-black.svg` / `mark-white.svg` — single-color versions (print, vinyl, one-color placements)
- `mark-amber.svg` — amber roof accent variant
- `favicon-simple.svg` / `favicon-simple-black.svg` — simplified geometry (fatter wheels, no hubs) for 16–32px
- `appicon-dark.svg` / `appicon-blue.svg` / `appicon-light.svg` — 512px rounded app-icon tiles
- `lockup-italic-dark.svg` / `-light.svg` — mark + italic ROOFTOP/AUTO + "A LITESPEED COMPANY"
- `lockup-block-dark.svg` / `-light.svg` — mark + block ROOFTOPAUTO + "DEALER PLATFORM"
- `lockup-italic-on-black.svg` / `lockup-block-on-white.svg` — same, with background baked in
- `lockup-stacked-dark.svg` — vertical lockup
- `monogram-dark.svg` / `monogram-blue.svg` / `monogram-transparent.svg` — R/A monogram

**brand/png/** — rasters at 1024/2240px plus favicons at 512/64/32/16

## Colors

| Role | Hex |
| --- | --- |
| Ink (primary background) | `#05070A` |
| Surface | `#0F141A` |
| Accent blue (primary) | `#3D8BFF` |
| Accent amber (secondary) | `#FFB020` |
| Paper / light text | `#F4F7FA` |
| Muted text | `#8A94A3` |
| Positive | `#2ED573` |

> These are placeholders for the Litespeed palette — send me the real hex codes and I'll regenerate every file.

## Type

- **Archivo** — 800 for the block wordmark, 900 italic for the ROOFTOP/AUTO wordmark and R/A monogram
- **IBM Plex Sans** — 500 for taglines and all UI/body copy
- Both are free on Google Fonts. The lockup SVGs use live text, so **install Archivo and IBM Plex Sans** before opening them, or have the type converted to outlines for final production files.

## Usage

- Minimum mark size: 20px with the standard geometry; below that use `favicon-simple.svg`.
- Clear space: half the chevron's width on all sides.
- Don't recolor the car and roof to two unrelated hues — roof carries the accent, body stays paper or ink.
- Don't stretch, add gradients, outline the wordmark, or set the wordmark in another typeface.
